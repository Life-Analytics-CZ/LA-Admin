# LifeAnalytics

## How To Deploy
Now pipeline does not exist and pushing version will rewrite existing stuff (TODO)
0. Make changes in new branch (or devel) 
1. push + merge with main
2. Then run commands on server.
```
cd web
git pull
docker compose -f docker-compose.production.yml down -v
docker compose -f docker-compose.production.yml up -d --build
docker compose -f docker-compose.production.yml run --rm django python manage.py migrate
docker compose -f docker-compose.production.yml run -v `pwd`:/app/life --rm django python manage.py import_categories /app/life/longevity2.csv
docker compose -f docker-compose.production.yml run -v `pwd`:/app/life --rm django python manage.py import_biomarkers /app/life/longevity2.csv
```
TODO: instead of building containers on server, download images from gitlab.

## WARNING
Currentnly it is deployed on IP address without SSL. It means that CSRF was disabled and once deployed on domain, must be reenabled (search for keyword INSECURE in production configuration file).
