from django.contrib import admin
from .models import BiomarkerCategory, Biomarker, BiomarkerRange


@admin.register(BiomarkerCategory)
class BiomarkerCategoryAdmin(admin.ModelAdmin):
    list_display = ("name",)
    search_fields = ("name",)


@admin.register(Biomarker)
class BiomarkerAdmin(admin.ModelAdmin):
    list_display = ("name", "category")
    list_filter = ("category",)
    search_fields = ("name", "category__name")


@admin.register(BiomarkerRange)
class BiomarkerRangeAdmin(admin.ModelAdmin):
    list_display = ("biomarker", "interval", "min_value", "max_value")
    list_filter = ("interval", "biomarker")
    search_fields = ("biomarker__name", "interval")
