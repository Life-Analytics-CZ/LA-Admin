import csv
from django.core.management.base import BaseCommand
from model.models import BiomarkerCategory, Biomarker, BiomarkerRange
from decimal import Decimal, InvalidOperation


class Command(BaseCommand):
    help = "Import biomarkers and their categories from a CSV file"

    def add_arguments(self, parser):
        parser.add_argument(
            "file_path", type=str, help="Path to the CSV file containing biomarker data"
        )

    def load_csv_to_dict(self, file_path):
        with open(file_path, mode="r") as file:
            csv_reader = csv.DictReader(file)
            data = [row for row in csv_reader]
        return data

    def handle(self, *args, **kwargs):
        file_path = kwargs["file_path"]
        content = self.load_csv_to_dict(file_path)

        # Mapping from CSV column names to interval choices
        # interval_mapping = {
        #     'dangerously_low': ('danger_low', 'norm_min'),
        #     'normal_low': ('norm_min', 'optmin'),
        #     'optimal': ('optmin', 'optmax'),
        #     'normal_high': ('optmax', 'norm_max'),
        #     'elevated': ('norm_max', 'elevated'),
        #     'dangerously_high': ('elevated', 'danger_high')
        # }

        interval_mapping = {
            "optimal": ("optmin", "optmax"),
            "doctor_normal": ("norm_min", "norm_max"),
            "normal_high": ("optmax", "elevated"),
            "elevated": ("elevated", "danger_high"),
            "dangerously_low": ("danger_low", "norm_min"),
            "dangerously_high": ("elevated", "danger_high"),
        }

        "optimal" "doctor_normal" "normal_high" "elevated" "dangerously_low" "dangerously_high"

        for row in content:
            self.stdout.write(self.style.NOTICE(f"Analyzing: {row}"))

            # Extract category and create or retrieve it
            category_name = row["Category"]
            category, _ = BiomarkerCategory.objects.get_or_create(name=category_name)

            # Extract biomarker details and create or retrieve it
            biomarker_name = row["Biomarker"]
            units = row["units"]
            biomarker, _ = Biomarker.objects.get_or_create(
                name=biomarker_name, category=category, units=units
            )

            # Extract and save each interval range
            for csv_column, interval_choice in interval_mapping.items():
                min_value = row[interval_choice[0]]
                max_value = row[interval_choice[1]]

                # Convert values to Decimal if they are not empty
                min_value = float(min_value) if min_value else None
                max_value = float(max_value) if max_value else None

                try:
                    min_value = round(Decimal(min_value), 4) if min_value else None
                    max_value = round(Decimal(max_value), 4) if max_value else None
                except (InvalidOperation, ValueError):
                    self.stdout.write(
                        self.style.WARNING(
                            f"Converting to decimal {min_value} or {max_value} failed for interval {interval_choice} in row {row}"
                        )
                    )
                    min_value = None
                    max_value = None

                # Create or update the BiomarkerRange for each interval
                if min_value is not None and max_value is not None:
                    BiomarkerRange.objects.update_or_create(
                        biomarker=biomarker,
                        interval=csv_column,
                        defaults={"min_value": min_value, "max_value": max_value},
                    )
                    self.stdout.write(
                        self.style.SUCCESS(
                            f'\tAdded or updated "{biomarker_name}" {csv_column} failed to improt {interval_choice} as values are {min_value} and {max_value}'
                        )
                    )
                else:
                    self.stdout.write(
                        self.style.ERROR(
                            f'\tFor "{biomarker_name}" {csv_column} failed to improt {interval_choice} as values are {min_value} and {max_value}'
                        )
                    )

            # Optional: Add a comment to the biomarker if it exists in the CSV
            comment = row.get("comment")
            if comment:
                biomarker.comment = comment
                biomarker.save()

            self.stdout.write(
                self.style.SUCCESS(
                    f"Added or updated biomarker '{biomarker_name}' in category '{category_name}'"
                )
            )
