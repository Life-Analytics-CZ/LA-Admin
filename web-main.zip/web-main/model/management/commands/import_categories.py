import csv

from django.core.management.base import BaseCommand

from model.models import BiomarkerCategory


class Command(BaseCommand):
    help = "Import biomarker categories from a CSV file"

    def add_arguments(self, parser):
        parser.add_argument(
            "file_path",
            type=str,
            help="Path to the CSV file containing biomarker categories",
        )

    def load_csv_to_dict(self, file_path):
        with open(file_path) as file:
            csv_reader = csv.DictReader(file)
            data = [row for row in csv_reader]
        return data

    def handle(self, *args, **kwargs):
        file_path = kwargs["file_path"]

        content = self.load_csv_to_dict(file_path)

        for row in content:
            category_name = row["Category"]  # Adjust if there are multiple columns

            # Avoid duplicate entries
            category, created = BiomarkerCategory.objects.get_or_create(
                name=category_name
            )

            if created:
                self.stdout.write(
                    self.style.SUCCESS(f"Successfully added category '{category_name}'")
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f"Category '{category_name}' already exists")
                )
